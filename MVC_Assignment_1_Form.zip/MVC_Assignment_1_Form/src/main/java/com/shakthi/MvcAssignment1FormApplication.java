package com.shakthi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcAssignment1FormApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvcAssignment1FormApplication.class, args);
	}

}
