package com.shakthi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.shakthi.Entity.User;
import com.shakthi.Repository.UserRepository;

@Controller
public class UserController {

    @Autowired
    private UserRepository userRepository;
    @GetMapping("/userForm")
    public String showForm(User user) {
        return "userForm";
    }

    @PostMapping("/userForm")
    public String submitForm(User user, Model model) {
        
        userRepository.save(user);
        System.out.println("Timings : "+user.getTimings()+"  name : "+user.getUsername()+" course : " +user.getCourse());
        model.addAttribute("message", "Successfully submitted");
        return "userForm";
    }

}
