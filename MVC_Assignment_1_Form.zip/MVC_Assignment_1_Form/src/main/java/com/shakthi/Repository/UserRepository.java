package com.shakthi.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.shakthi.Entity.User;

public interface UserRepository extends JpaRepository<User, Long> {

}
